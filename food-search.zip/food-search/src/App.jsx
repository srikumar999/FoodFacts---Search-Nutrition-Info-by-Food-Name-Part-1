import { useState } from "react";
import SearchBar from "./components/SearchBar";
import FoodList from "./components/FoodList";
import "./App.css";

function App() {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState(null);

  const handleSearch = async (query) => {
    setLoading(true);
    setSearched(true);
    setError(null);
    setResults([]);

    try {
      const encoded = encodeURIComponent(query);
      const url = `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encoded}&search_simple=1&action=process&json=1&page_size=24`;
      const res = await fetch(url);

      if (!res.ok) throw new Error(`API error: ${res.status}`);

      const data = await res.json();
      const filtered = (data.products || []).filter(
        (p) => p.product_name && p.product_name.trim() !== ""
      );
      setResults(filtered);
    } catch (err) {
      setError("Something went wrong. Please try again.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-tag">Nutrition Explorer</div>
        <h1 className="app-title">
          What are you<br />
          <span className="accent-text">eating today?</span>
        </h1>
        <p className="app-subtitle">
          Search millions of food products and instantly see their nutritional details.
        </p>
        <SearchBar onSearch={handleSearch} />
      </header>

      <main className="app-main">
        {loading && (
          <div className="state-container">
            <div className="spinner" />
            <p className="state-msg">Fetching nutrition data...</p>
          </div>
        )}

        {!loading && error && (
          <div className="state-container">
            <span className="state-icon">⚠️</span>
            <p className="state-msg">{error}</p>
          </div>
        )}

        {!loading && !error && !searched && (
          <div className="state-container empty-state">
            <span className="state-icon">🥦</span>
            <p className="state-msg">Search for any food product above to get started.</p>
          </div>
        )}

        {!loading && !error && searched && results.length === 0 && (
          <div className="state-container">
            <span className="state-icon">🔍</span>
            <p className="state-msg">No products found. Try a different search term.</p>
          </div>
        )}

        {!loading && results.length > 0 && (
          <>
            <p className="results-count">{results.length} products found</p>
            <FoodList products={results} />
          </>
        )}
      </main>
    </div>
  );
}

export default App;
